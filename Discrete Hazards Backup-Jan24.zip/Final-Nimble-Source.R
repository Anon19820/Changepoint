sort_vec <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('ii','ii1'))),
  #X matrix tstart; tstop,status, X var all
  run = function(X = double(1)){
    lx      <- dim(X)[1]
    lxMin1  <- lx-1
    madeChange <- TRUE        
    while(madeChange) {
      madeChange <- FALSE
      for (ii in 1:lxMin1) {
        ii1 <- ii+1
        if (X[ii] > X[ii1]) {
          tmp    <- X[ii]
          X[ii]  <- X[ii1]
          X[ii1] <- tmp
          madeChange <- TRUE
        }
      }
    }
    return(X)
    returnType(double(1))
  }
)


LL_beta <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('i','j'))),
  run = function(X_res_mat = double(2),
                 beta_1 = double(2),
                 beta_2 = double(2),
                 trt_wane = double(0),
                 lambda_wane = double(0),
                 nrow_X = double(0),
                 n = double(0)
  ){
    ncol_X = dim(X_res_mat)[2];
    X_res <- matrix(nrow = nrow_X, ncol = ncol_X)
    X_res[1:nrow_X, 1:ncol_X] <- X_res_mat[1:nrow_X, 1:ncol_X]
    
    #nrow_X = dim(X_res)[1];
    n_int = dim(beta_1)[2];
    
    param_1 <- matrix(nrow = nrow_X, ncol = n_int)
    param_2 <- matrix(nrow = nrow_X, ncol = n_int)
    
    param_1_final <- numeric(nrow_X)
    param_2_final <- numeric(nrow_X)
    res <- numeric(nrow_X)
    
    
    for(i in 1:n_int){
      param_1[,i] <-   X_res[,6:ncol_X] %*% beta_1[,i];
      param_2[,i] <-   X_res[,6:ncol_X] %*% beta_2[,i];
      
    }
    
    for(i in 1:nrow_X){
      param_1_final[i] <-  exp(param_1[i,X_res[i,4]])
      param_2_final[i] <-  exp(param_2[i,X_res[i,4]])
      
      res[i] <- hweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],1)*X_res[i,3]-
        (HweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],0)-HweibullPH(X_res[i,1],param_1_final[i],param_2_final[i],0))   
      
    }
    
    res_final <- numeric(n);
    for(i in 1:n){
      res_final[i] <- sum(res[X_res[,5]==i])
    }
    
    return(res_final)
    returnType(double(1)) # return type declaration
    
    
  }
)

survSplit <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('i','j','p','k'))),
  #X matrix tstart; tstop,status, X var all
  run = function(X = double(2),
                 cut = double(1)){ # type declarations
    
    n = dim(X)[1];
    ncut = length(cut);
    ncol = dim(X)[2]
    tstart = X[,1]
    tstop = X[,2]
    status_orig = X[,3]
    extra =0;
    extra_cov = ncol- 3 #must have tstart; tstop,status,
    for (i in 1:n) {
      for (j in 1:ncut){
        if (cut[j] > tstart[i] & cut[j] < tstop[i]){
          extra = extra + 1;
        }
      }
    }
    n2 <- n + extra
    
    start <- numeric(n2);
    interval <- numeric(n2);
    end <- numeric(n2);
    status <- numeric(n2);
    id <- numeric(n2);
    X_res <- matrix(nrow = n2, ncol = ncol+2)
    
    k =1;
    
    for (i in 1:n) {
      
      j_eval <- 1
      
      for(j in 1:ncut){
        if(cut[j] <= tstart[i]){
          j_eval <- j_eval + 1
        }
      }
      
      start[k] = tstart[i];
      interval[k] = j_eval;
      id[k] = i;
      for(p in 4:ncol){
        X_res[k,p+2] <-X[i,p]
      }
      
      for (j in j_eval:ncut){
        
        if(cut[j] < tstop[i]){
          
          if (cut[j] > tstart[i]){
            end[k] = cut[j];
            status[k] = 0;
            k =k+1;
            start[k] = cut[j];
            interval[k] = j+1;
            id[k] = i;
            for(p in 4:ncol){
              X_res[k,p+2] <-X[i,p]
            }
          }
        }
      }
      end[k] = tstop[i];
      status[k] =status_orig[i];
      for(p in 4:ncol){
        X_res[k,p+2] <-X[i,p]
      }
      k <- k +1 ;
    }
    
    X_res[,1] <- start
    X_res[,2] <- end
    X_res[,3] <- status
    X_res[,4] <- interval
    X_res[,5] <- id
    #X_res[,6] <- 1 #Intercept
    
    return(X_res)
    returnType(double(2)) # return type declaration
  })

hweibullPH <- nimbleFunction(
  #X matrix tstart; tstop,status, X var all
  run = function(x = double(0),
                 scale = double(0),
                 shape = double(0),
                 log = double(0)){
    
    res <- scale*shape*(x^(shape-1))
    
    if(log ==1){
      return(log(res))
      # returnType(double(0))
    }else{
      return(res)
    }
    returnType(double(0))
    
  }
)

survSplit_mat <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('j'))),
  run = function(X = double(2),
                 cut = double(1)){
    
    X_res <- survSplit(X, cut)
    n <- dim(X)[1]
    nrow_X = dim(X_res)[1];
    ncol_X = dim(X_res)[2];
    n_int = length(cut) #We cut is (cp, 1000)
    
    X_res_final <- matrix(nrow = n*n_int, ncol = ncol_X +1) #max number of rows; Need to keep it constant.
    for(j in 1:ncol_X){
      X_res_final[1:nrow_X,j] <- X_res[1:nrow_X,j]
    }
    
    X_res_final[1, ncol_X +1] <- nrow_X
    X_res_final[2, ncol_X +1] <- n
    
    
    return(X_res_final)
    returnType(double(2)) # return type declaration
  }
)

HweibullPH <- nimbleFunction(
  #X matrix tstart; tstop,status, X var all
  run = function(q = double(0),
                 
                 scale = double(0),
                 shape = double(0),
                 log = double(0)){
    
    
    
    res <-  scale*(q^shape)
    
    if(log ==1){
      return(log(res))
      #returnType(double(0))
    }else{
      return(res)
      
    }
    returnType(double(0))
  }
)

mat_adjust <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('i','j'))),
  #X matrix tstart; tstop,status, X var all
  run = function(mat = double(2),
                 mat2 = double(2)){
    n_col = dim(mat)[2];
    n_row = dim(mat)[1];
    mat_final = matrix(nrow = n_row, ncol = n_col)
    for(i in 1:n_row){
      
      for(j in 1:n_col){
        
        if(mat2[i,j] == 2){
          
          mat_final[i,1:n_col] <- mat[i,j]
          
        }else{
          mat_final[i,j] <- mat[i,j]*mat2[i,j]
        }
      }
      
    }
    
    
    return(mat_final)
    returnType(double(2))
  }
)
LL_beta <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('i','j'))),
  run = function(X_res_mat = double(2),
                 beta_1 = double(2),
                 beta_2 = double(2),
                 trt_wane = double(0),
                 lambda_wane = double(0),
                 nrow_X = double(0),
                 n = double(0)
  ){
    ncol_X = dim(X_res_mat)[2];
    X_res <- matrix(nrow = nrow_X, ncol = ncol_X)
    X_res[1:nrow_X, 1:ncol_X] <- X_res_mat[1:nrow_X, 1:ncol_X]
    
    #nrow_X = dim(X_res)[1];
    n_int = dim(beta_1)[2];
    
    param_1 <- matrix(nrow = nrow_X, ncol = n_int)
    param_2 <- matrix(nrow = nrow_X, ncol = n_int)
    
    param_1_final <- numeric(nrow_X)
    param_2_final <- numeric(nrow_X)
    res <- numeric(nrow_X)
    
    
    for(i in 1:n_int){
      param_1[,i] <-   X_res[,6:ncol_X] %*% beta_1[,i];
      param_2[,i] <-   X_res[,6:ncol_X] %*% beta_2[,i];
      
    }
    
    for(i in 1:nrow_X){
      param_1_final[i] <-  exp(param_1[i,X_res[i,4]])
      param_2_final[i] <-  exp(param_2[i,X_res[i,4]])
      
      res[i] <- hweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],1)*X_res[i,3]-
        (HweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],0)-HweibullPH(X_res[i,1],param_1_final[i],param_2_final[i],0))
      
      
    }
    
    res_final <- numeric(n);
    for(i in 1:n){
      res_final[i] <- sum(res[X_res[,5]==i])
    }
    
    return(res_final)
    returnType(double(1)) # return type declaration
    
    
  }
)


mod_cp <- nimbleCode({
  C <- 10000
  cp_unsort[1] <- 0
  for(i in 1:N_CP){
    params_cp[i] ~ dunif(0, MAXX)
    cp_unsort[i+1] <- params_cp[i]
  }
  cp_unsort[N_CP+2] <- 1000
  cp[1:(N_CP+2)] <- sort_vec(cp_unsort[1:(N_CP+2)])
  
  for(i in 2:(N_CP+1)){
    diff[i-1] <- cp[i]-cp[i-1]
    #log_diff[i-1] <- log(diff[i])
  }
  
  diff[N_CP+1] <- 1 #need to padd but needs to evaluate to 0
  
  #sum_log_diff <- sum(log_diff[1:N_CP])
  
  log_prior <- loggam(2*N_CP +2) + sum(log(diff[1:(N_CP+1)])) - ((2*N_CP +1)*log(MAXX))
  zero_prior ~ dpois(C - log_prior)
  
  #
  
  data_mod[1:(N*n_int),1:(df_ncol+3) ] <- survSplit_mat(data[1:N,1:df_ncol], cp[2:(N_CP+2)])
  
  for(i in 1:nrow_beta){
    for(j in 1:ncol_beta){
      beta_1_sim[i,j] ~ dnorm(0,1)
      beta_2_sim[i,j] ~ dnorm(0,1)
    }
  }
  
  beta_1[1:nrow_beta,1:ncol_beta] <- mat_adjust(beta_1_sim[1:nrow_beta,1:ncol_beta],beta_1_ind[1:nrow_beta,1:ncol_beta]) 
  beta_2[1:nrow_beta,1:ncol_beta] <- mat_adjust(beta_2_sim[1:nrow_beta,1:ncol_beta],beta_2_ind[1:nrow_beta,1:ncol_beta]) 
  
  
  LL[1:N] <- LL_beta(data_mod[1:(N*n_int),1:(df_ncol+2)],
                     beta_1[1:nrow_beta,1:ncol_beta],
                     beta_2[1:nrow_beta,1:ncol_beta],
                     0,#trt_wane,
                     1, #lambda_wane,
                     data_mod[1,(df_ncol+3)], #nrow_X
                     data_mod[2,(df_ncol+3)]) #n
  
  zero ~ dpois(-sum(LL[1:N]) + C)
  
})