library("nimble");
library("nimbleHMC");
library("dplyr");
library("survival");

#pathway <- "C:\\Users\\phili\\OneDrive\\PhD\\R_packages_2023\\PiecewiseChangepoint\\Files_Replicate_Analysis\\Chapter 5 Change-point Models\\"
pathway <- "~/Change-Point Simulation Studies/Simulation Study 2023/"
source(paste0(pathway, "Nimble Functions.R"))


E1690.dat <- read.table(paste0(pathway,"e1690.missing.dat"),
                        header=TRUE)

# Ibhrahim data
#Drop PFS events with time equal zero
E1690.dat <- E1690.dat[-which(E1690.dat$FAILTIME ==0),]

#Convert to the correct notation for survival objects
E1690.dat[which(E1690.dat$FAILCENS == 1),"FAILCENS"] <-0
E1690.dat[which(E1690.dat$FAILCENS == 2),"FAILCENS"] <-1
E1690.dat[which(E1690.dat$SURVCENS == 1),"SURVCENS"] <-0
E1690.dat[which(E1690.dat$SURVCENS == 2),"SURVCENS"] <-1
E1690.dat$AGE <- as.numeric(E1690.dat$AGE)
E1690.dat$AGE[is.na(E1690.dat$AGE)] <- mean(E1690.dat$AGE, na.rm = T)
E1690.dat$AGE_scale <- as.numeric(scale(E1690.dat$AGE))
E1690.dat$AGE_scale_abs <- abs(E1690.dat$AGE_scale)
E1690.dat$TRT <- E1690.dat$TRT -1
E1690.dat$Intercept <- 1
E1690.dat_final <- E1690.dat[,c("SURVTIME","SURVCENS","Intercept","TRT", "AGE_scale")]
E1690.dat_final <- cbind(tstart = 0,E1690.dat_final)


beta_1 <- beta_2 <- matrix(1, byrow = FALSE, ncol = 2, nrow = 3)
beta_2[2:3,1:2] <-0

# nimble_data <- list(data=as.matrix(E1690.dat_final), zero = 0,
#                     zero_prior = 0,
#                     max_cp = max(data_mod[,1])*0.7)
# 
# N_CP <- 1
# 
# constants_nimble = list(N_CP = N_CP,
#                         n_int = N_CP+1,
#                         N = nrow(nimble_data$data),
#                         df_ncol = ncol(nimble_data$data),
#                         MAXX = max(data_mod[,1])) #Age plus the TRT



data_nimble = list(zero = 0,
                   zero_prior = 0,
                   data =as.matrix(E1690.dat_final))
N_CP <- 1

constants_nimble = list(N_CP = N_CP,
                        n_int = N_CP+1,
                        N = nrow(data_nimble$data),
                        df_ncol = ncol(data_nimble$data),
                        #N_covar = 1+N_CP+1,
                        MAXX = max(data_nimble$data[,2]),
                        beta_1_ind = beta_1,
                        beta_2_ind = beta_2) #Age plus the TRT

constants_nimble[["nrow_beta"]] = nrow(constants_nimble$beta_1_ind)
constants_nimble[["ncol_beta"]] = ncol(constants_nimble$beta_1_ind)


# time_vec <- seq(0,10, by = 0.25)
# surv_mat <- cbind(tstart = 0, time =time_vec , status = 0, TRT = 1, AGE_scale = 0)
# surv_mat2 <- cbind(tstart = 0, time =time_vec , status = 0, TRT = 0, AGE_scale = 0)
# surv_mat_final <- rbind(surv_mat,surv_mat2)



#constants_nimble[["n_pred"]] <- nrow(surv_mat_final)

mat_adjust <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('i','j'))),
  #X matrix tstart; tstop,status, X var all
  run = function(mat = double(2),
                 mat2 = double(2)){
    n_col = dim(mat)[2];
    n_row = dim(mat)[1];
    mat_final = matrix(nrow = n_row, ncol = n_col)
    for(i in 1:n_row){
      
      for(j in 1:n_col){
        
        if(mat2[i,j] == 2){
          mat_final[i,j] <- mat[i,1]
          }else{
          mat_final[i,j] <- mat[i,j]*mat2[i,j]
        }
      }
      
    }
    
    
    return(mat_final)
    returnType(double(2))
  }
)



mod_cp <- nimbleCode({
  C <- 10000
  cp_unsort[1] <- 0
  for(i in 1:N_CP){
    params_cp[i] ~ dunif(0, MAXX)
    cp_unsort[i+1] <- params_cp[i]
  }
  cp_unsort[N_CP+2] <- 1000
  cp[1:(N_CP+2)] <- sort_vec(cp_unsort[1:(N_CP+2)])
  
  for(i in 2:(N_CP+1)){
    diff[i-1] <- cp[i]-cp[i-1]
    #log_diff[i-1] <- log(diff[i])
  }
  
  diff[N_CP+1] <- 1 #need to padd but needs to evaluate to 0
  
  #sum_log_diff <- sum(log_diff[1:N_CP])
  
  log_prior <- loggam(2*N_CP +2) + sum(log(diff[1:(N_CP+1)])) - ((2*N_CP +1)*log(MAXX))
  zero_prior ~ dpois(C - log_prior)
  
  #
  
  data_mod[1:(N*n_int),1:(df_ncol+3) ] <- survSplit_mat(data[1:N,1:df_ncol], cp[2:(N_CP+2)])
  
  for(i in 1:nrow_beta){
    for(j in 1:ncol_beta){
      beta_1_sim[i,j] ~ dnorm(0,1)
      beta_2_sim[i,j] ~ dnorm(0,1)
    }
  }
  
  beta_1[1:nrow_beta,1:ncol_beta] <- mat_adjust(beta_1_sim[1:nrow_beta,1:ncol_beta],beta_1_ind[1:nrow_beta,1:ncol_beta]) 
  beta_2[1:nrow_beta,1:ncol_beta] <- mat_adjust(beta_2_sim[1:nrow_beta,1:ncol_beta],beta_2_ind[1:nrow_beta,1:ncol_beta]) 
  
  
  LL[1:N] <- LL_beta(data_mod[1:(N*n_int),1:(df_ncol+2)],
                     beta_1[1:nrow_beta,1:ncol_beta],
                     beta_2[1:nrow_beta,1:ncol_beta],
                     0,#trt_wane,
                     1, #lambda_wane,
                     data_mod[1,(df_ncol+3)], #nrow_X
                     data_mod[2,(df_ncol+3)]) #n
  
  zero ~ dpois(-sum(LL[1:N]) + C)
  
})
# survSplit(as.matrix(data_nimble$data), c(1,100))
#survSplit_mat(head(data_nimble$data), c(2,1000))
survSplit_mat <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('j'))),
  run = function(X = double(2),
                 cut = double(1)){
    
  X_res <- survSplit(X, cut)
  n <- dim(X)[1]
  nrow_X = dim(X_res)[1];
  ncol_X = dim(X_res)[2];
  n_int = length(cut) #We cut is (cp, 1000)

  X_res_final <- matrix(nrow = n*n_int, ncol = ncol_X +1) #max number of rows; Need to keep it constant.
  for(j in 1:ncol_X){
    X_res_final[1:nrow_X,j] <- X_res[1:nrow_X,j]
  }

  X_res_final[1, ncol_X +1] <- nrow_X
  X_res_final[2, ncol_X +1] <- n


  return(X_res_final)
  returnType(double(2)) # return type declaration
  }
)

LL_beta <- nimbleFunction(
  buildDerivs = list(run = list(ignore = c('i','j'))),
  run = function(X_res_mat = double(2),
                 beta_1 = double(2),
                 beta_2 = double(2),
                 trt_wane = double(0),
                 lambda_wane = double(0),
                 nrow_X = double(0),
                 n = double(0)
                 ){
    ncol_X = dim(X_res_mat)[2];
    X_res <- matrix(nrow = nrow_X, ncol = ncol_X)
    X_res[1:nrow_X, 1:ncol_X] <- X_res_mat[1:nrow_X, 1:ncol_X]
    
    #nrow_X = dim(X_res)[1];
    n_int = dim(beta_1)[2];
    
    param_1 <- matrix(nrow = nrow_X, ncol = n_int)
    param_2 <- matrix(nrow = nrow_X, ncol = n_int)
    
    param_1_final <- numeric(nrow_X)
    param_2_final <- numeric(nrow_X)
    res <- numeric(nrow_X)
    
    
    for(i in 1:n_int){
      param_1[,i] <-   X_res[,6:ncol_X] %*% beta_1[,i];
      param_2[,i] <-   X_res[,6:ncol_X] %*% beta_2[,i];
      
    }
    
    for(i in 1:nrow_X){
      param_1_final[i] <-  exp(param_1[i,X_res[i,4]])
      param_2_final[i] <-  exp(param_2[i,X_res[i,4]])
      
      #if(type == 1){
        res[i] <- hweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],1)*X_res[i,3]-
          (HweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],0)-HweibullPH(X_res[i,1],param_1_final[i],param_2_final[i],0))
        
      # }else if(type == 2){ #Survival
      #   if(trt_wane == 1 & X_res[i, 7] == 1 & X_res[i, 4] == n_int){ #if we have a waning of treatment, treatment arm, and final interval
      #     #    
      #     #     initial_HR <- exp(beta_1[2,n_int-1])
      #     t_end <- X_res[i,2]
      #     t_start <- X_res[i,1] #change-point
      #     #HR_wane <- 1-(1-initial_HR)*exp(-lambda_wane*(t_end-t_start))
      #     
      #     upper_inc_gamma1 <- exp(loggam(param_2_final[i]))*(1-pgamma(lambda_wane*t_end,param_2_final[i],1))
      #     upper_inc_gamma2 <- exp(loggam(param_2_final[i]))*(1-pgamma(lambda_wane*t_start,param_2_final[i],1))
      #     upper_int <- (t_end^param_2_final[i])/param_2_final[i]-(upper_inc_gamma1*(initial_HR-1)*exp(t_start*lambda_wane)*(t_end^param_2_final[i]))/((lambda_wane*t_end)^param_2_final[i])
      #     lower_int <- (t_start^param_2_final[i])/param_2_final[i]-(upper_inc_gamma2*(initial_HR-1)*exp(t_start*lambda_wane)*(t_start^param_2_final[i]))/((lambda_wane*t_start)^param_2_final[i])
      #     
      #     
      #     res[i] <- ((upper_int - lower_int)*param_2_final[i]*param_1_final[i])#*step(time[i]-cp[k]) #Has to be treatment and cp < time
      #     
      #     
      #     
      #     
      #   }else{
      #     res[i] <- (HweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],0)-HweibullPH(X_res[i,1],param_1_final[i],param_2_final[i],0))
      #     
      #   }
      #   
      # }else{ #hazard
        
      #   res[i] <- hweibullPH(X_res[i,2],param_1_final[i],param_2_final[i],0)*X_res[i,3] #must be final interval for hazard
      #   
      #   if(trt_wane == 1 & X_res[i, 7] == 1 & X_res[i, 4] == n_int){
      #     t_end <- X_res[i,2]
      #     t_start <- X_res[i,1] #change-point
      #     initial_HR <- exp(beta_1[2,n_int-1])
      #     HR_wane <- 1-(1-initial_HR)*exp(-lambda_wane*(t_end-t_start))
      #     res[i] <- res[i]*HR_wane
      #   }
      #   
      #   
      # }
      
    }
    
    res_final <- numeric(n);
    for(i in 1:n){
      res_final[i] <- sum(res[X_res[,5]==i])
    }
    
    return(res_final)
    returnType(double(1)) # return type declaration
    
    
  }
)

inits_nimble <-function(){
  # list(params_cp = runif(constants_nimble$N_CP,min = 0.5,max = (constants_nimble$MAXX/constants_nimble$N_CP)*0.5)
  # )
  
  list(params_cp = 0.5, 
       beta_1_sim = matrix(0,nrow= 3, ncol = 2),
       beta_2_sim = matrix(0,nrow= 3, ncol = 2))
}
#https://oliviergimenez.github.io/nimble-workshop/#25
mod_cp_nimble <- nimbleMCMC(mod_cp,
                      data = data_nimble,
                      constants = constants_nimble,
                      monitors = c("beta_1", "beta_2","cp", "LL", "log_prior"),
                      niter = 10000,
                      inits = inits_nimble,
                      nchains =2,
                      nburnin = 50)

mod_cp_nimble[[1]][,"cp[2]"]

mod_wei_mat <- do.call("rbind", mod_cp_nimble)

index_save <- grep("cp|beta",colnames(mod_wei_mat))

colnames_save <- index_save[apply(mod_wei_mat[,index_save],2, function(x){ifelse(length(unique(x)) ==1, FALSE,TRUE)})]

mcmc_list_eval <- lapply(mod_cp_nimble,function(x){x[,colnames_save]})
mcmc_list_eval <- lapply(mcmc_list_eval,as.mcmc)

ggmcmc(ggs(coda::as.mcmc.list(mcmc_list_eval)), file = gen_pathway(paste0(pathway,"test/","MCMC_diag.pdf")))



mod_cp_mod <- nimbleModel(mod_cp,
                       data = data_nimble,
                       constants = constants_nimble,
                       buildDerivs = TRUE)

mod_cp_mod$getDependencies("cp[1]")
MCMC_config <- configureMCMC(mod_cp_mod)#, onlySlice =TRUE)
#MCMC_config$removeSamplers(c('beta_2_sim[]','beta_1_sim[]'), print = FALSE)
#MCMC_config$addSampler(target = c('beta_1_sim[]', 'beta_2_sim[]'), type = "RW_block")#'NUTS')

 
# MCMC_config$addSampler(target = 'cp[1]', type = 'slice')
# MCMC_config$monitors
#https://r-nimble.org/nimbleExamples/nimble_customizing_mcmc.html

modMCMC <- buildMCMC(MCMC_config)
cmod_cp_mod <- compileNimble(mod_cp_mod)
Cmod <- compileNimble(modMCMC, project = mod_cp_mod)
Cmod$modMCMC$run(100)




cmod_cp <- compileNimble(mod_cp)



$getDependencies("cp[1]")
