
library("nimble");
library("nimbleHMC");
library("dplyr");
library("survival");
library("parallel")
parallel::detectCores()
#pathway <- "C:\\Users\\phili\\OneDrive\\PhD\\R_packages_2023\\PiecewiseChangepoint\\Files_Replicate_Analysis\\Chapter 5 Change-point Models\\"
pathway <- "~/Change-Point Simulation Studies/Simulation Study 2023/"
source(paste0(pathway, "Final-Nimble-Source.R"))



set.seed(123)
n_sim <- 500
df_sim <- cbind(tstart = 0, time = rexp(n_sim), status = 1,
                Intercept =1, trt = rbinom(n_sim,1,0.5),
                age_scale = rnorm(n_sim))


n.thin <- 5
n.burnin <- 5000
n.samp <-  10000


E1690.dat <- read.table(paste0(pathway,"e1690.missing.dat"),
                        header=TRUE)

# Ibhrahim data
#Drop PFS events with time equal zero
E1690.dat <- E1690.dat[-which(E1690.dat$FAILTIME ==0),]

#Convert to the correct notation for survival objects
E1690.dat[which(E1690.dat$FAILCENS == 1),"FAILCENS"] <-0
E1690.dat[which(E1690.dat$FAILCENS == 2),"FAILCENS"] <-1
E1690.dat[which(E1690.dat$SURVCENS == 1),"SURVCENS"] <-0
E1690.dat[which(E1690.dat$SURVCENS == 2),"SURVCENS"] <-1
E1690.dat$AGE <- as.numeric(E1690.dat$AGE)
E1690.dat$AGE[is.na(E1690.dat$AGE)] <- mean(E1690.dat$AGE, na.rm = T)
E1690.dat$AGE_scale <- as.numeric(scale(E1690.dat$AGE))
E1690.dat$AGE_scale_abs <- abs(E1690.dat$AGE_scale)
E1690.dat$TRT <- E1690.dat$TRT -1
E1690.dat$Intercept <- 1
E1690.dat_final <- E1690.dat[,c("SURVTIME","SURVCENS","Intercept","TRT", "AGE_scale")]
E1690.dat_final <- cbind(tstart = 0,E1690.dat_final)

df_sim <- E1690.dat_final

beta_1 <- beta_2 <- matrix(1, byrow = FALSE, ncol = 2, nrow = 3)
beta_2[2:3,1:2] <-0

data_nimble = list(zero = 0,
                   zero_prior = 0,
                   data =as.matrix(df_sim))
N_CP <- 1

constants_nimble = list(N_CP = N_CP,
                        n_int = N_CP+1,
                        N = nrow(data_nimble$data),
                        df_ncol = ncol(data_nimble$data),
                        #N_covar = 1+N_CP+1,
                        MAXX = max(data_nimble$data[,2]),
                        beta_1_ind = beta_1,
                        beta_2_ind = beta_2) #Age plus the TRT

constants_nimble[["nrow_beta"]] = nrow(constants_nimble$beta_1_ind)
constants_nimble[["ncol_beta"]] = ncol(constants_nimble$beta_1_ind)

inits_nimble <-function(){
  
  list(params_cp = 0.5, 
       beta_1_sim = matrix(0,nrow= 3, ncol = 2),
       beta_2_sim = matrix(0,nrow= 3, ncol = 2))
}



run_MCMC_allcode <- function(seed =123, nimble_data, nimble_constants, model_code,inits_nimble, useWAIC = TRUE, niter_final = 5000,
                             n_thin = 5, n_burnin = NULL,
                             monitors, source_code = NULL) {
  library(nimble)
  
    source(source_code)
  if(!is.null(n_burnin)){
    n_burnin <- (niter_final*n_thin)/5 
  }
  
  myModel <- nimbleModel(code = model_code,
                         data = nimble_data,
                         constants = nimble_constants,
                         inits = inits_nimble())
  
  conf <- configureMCMC(myModel, onlySlice =TRUE)
  myMCMC <- buildMCMC(conf, monitors = monitors)
  
  CmyModel <- compileNimble(myModel)
  
  #if(useWAIC) 
  # monitors <- myModel$getParents(myModel$getNodeNames(dataOnly = TRUE), stochOnly = TRUE)
  ## One may also wish to add additional monitors
 
  CmyMCMC <- compileNimble(myMCMC, project = myModel)
  
  results <- runMCMC(CmyMCMC, niter = niter_final*n_thin + n_burnin, setSeed = seed, nburnin = n_burnin, thin = n_thin)
  
  return(results)
}
undebug(run_MCMC_allcode)


monitors_vec <- c("beta_1", "beta_2","cp", "LL", "log_prior")

this_cluster <- makeCluster(2)
start_time_nimble <- Sys.time()

chain_output <- parLapply(cl = this_cluster, X = 1:2, 
                          fun = run_MCMC_allcode, 
                          nimble_data = data_nimble, 
                          nimble_constants =constants_nimble,
                          model_code = mod_cp,
                          inits_nimble = inits_nimble,
                          useWAIC = FALSE,
                          monitors = monitors_vec,
                          niter_final = n.samp,
                          n_thin = n.thin,
                          n_burnin =  n.burnin,
                          source_code = paste0(pathway, "Final-Nimble-Source.R"))

par(mfrow = c(2,2))
for (i in 1:2) {
  this_output <- chain_output[[i]]
  #plot(this_output[,"cp[2]"], type = "l", ylab = 'change-point')
  plot(density(this_output[,"params_cp[1]"]), type = "l", ylab = 'change-point')
  
}
# It's good practice to close the cluster when you're done with it.
stopCluster(this_cluster)


end_time_nimble <- Sys.time()
end_time_nimble - start_time_nimble



#https://stackoverflow.com/questions/52781170/using-different-simulation-functions-in-each-core-with-parallelclusterapply



data_jags <- list()
data_jags$N <- nrow(E1690.dat_final)
data_jags$time <- E1690.dat_final$SURVTIME
data_jags$status <- E1690.dat_final$SURVCENS
data_jags$MAXX <- max(E1690.dat_final$SURVTIME)
data_jags$N_CP <- 1
data_jags$X_mat<- as.matrix(cbind(1 ,E1690.dat_final$TRT, E1690.dat_final$AGE_scale))
data_jags$beta_1_ind <- beta_1
data_jags$beta_2_ind <- beta_2

#If you wanted a fixed change-point... Set to zero if you want the change-point to be estimated
data_jags$cp_fix <- c(0, 1, 5)
data_jags$cp_fixed <- 0
mod <- "wei"
#Change-inits

source(paste0(pathway, "Jags_codes2.R"))

start_time_jags <- Sys.time()

mod.cp_scenario1 <- runjags::run.jags(
  model = get(paste0("jags.piecewise_wei_chng")),
  #model = jags.piecewise.expo_chng,
  data = data_jags,
  n.chains = 2,
  monitor = c("cp", "beta_cp","beta_cp_anc", "total_loglik","loglik"),
  sample=n.samp,
  thin = n.thin,
  burnin = n.burnin,
  inits = inits,
  adapt =0,
  method ='rjparallel',
  summarise = FALSE)



end_time_jags <- Sys.time()
end_time_jags - start_time_jags
plot(density(mod.cp_scenario1$mcmc[[1]][,"cp[2]"]))
plot(density(mod.cp_scenario1$mcmc[[2]][,"cp[2]"]))
