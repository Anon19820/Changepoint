library("nimble");
library("dplyr");
library("survival");
library("runjags");
library("ggplot2")
library("mcp")

inits <- function(){
  list(unif = runif(data_jags$N_CP,min = data_jags$t_int,max = data_jags$MAXX/data_jags$N_CP)
  )
}

pathway <- "~/Change-Point Simulation Studies/Simulation Study 2023/"


path_BRIM <- paste0(pathway,"BRIM-3/BRIM-3/")

TA269_OS_D_df <- xlsx::read.xlsx(paste0(path_BRIM,"Dacarbazine","/Pseudo_IPD.xlsx"), header = T, sheetIndex = 1)[,-1]
TA269_OS_D_df$arm <- 0

TA269_OS_V_df <- xlsx::read.xlsx(paste0(path_BRIM,"Vemurafenib","/Pseudo_IPD.xlsx"), header = T, sheetIndex = 1)[,-1]
TA269_OS_V_df$arm <- 1

TA269_df_all <- rbind(TA269_OS_V_df,TA269_OS_D_df)

TA269_df_all <- TA269_df_all %>% mutate(Treatment = ifelse(arm == 1,
                                                           "Vemurafenib",
                                                           "Dacarbazine"))
TA269_df_all$Treatment <- as.factor(TA269_df_all$Treatment)
TA269_df_all$Treatment <- relevel(TA269_df_all$Treatment, ref ="Dacarbazine")

TA269.km <- survfit(Surv(time,status)~Treatment, data = TA269_df_all)


df_collapse <- survival::survSplit(Surv(time, status) ~Treatment, TA269_df_all,
            cut=1:16, episode ="timegroup")


sumTA269 <- summary(TA269.km, t = 1:17)
df_collapse_all <- df_collapse %>% mutate(texpos = time-tstart) %>% group_by(timegroup,Treatment) %>% 
  summarize(status_sum = sum(status),
            texpos_sum = sum(texpos),
            atRisk = n()) %>% mutate(haz = status_sum/texpos_sum) %>% ungroup() %>% group_by(Treatment) %>% arrange(Treatment)


sumTA269_2 <- summary(TA269.km, t = 0:16)
df_collapse_all$atRisk2 <- (sumTA269$n.risk+sumTA269_2$n.risk)/2


#Improve this atRisk by taking the average from the start to the end 

mean(df_collapse_all$atRisk2)

#Double check to see if this is precicse enough
length(sumTA269$n.risk);length(df_collapse_all$timegroup)
glm_fit <- glm(status_sum ~ log(timegroup) + Treatment + offset(log(atRisk2)), family=poisson, data=df_collapse_all)

glm_fit$coefficients[1] + log(2)*glm_fit$coefficients[2] + log(df_collapse_all$atRisk2[2])
predict(glm_fit)[2]

true_model  <- exp(glm_fit$coefficients[1] + log(1:10)*glm_fit$coefficients[2] + log(df_collapse_all$atRisk2[1:10]))/df_collapse_all$atRisk2[1:10]
applied <- exp(glm_fit$coefficients[1] + log(1:10)*glm_fit$coefficients[2] + log(mean(df_collapse_all$atRisk2)))/mean(df_collapse_all$atRisk2)
applied2 <- exp(glm_fit$coefficients[1] + log(1:10)*glm_fit$coefficients[2])

theoretical <- summary(fit_flexsurv, type = "hazard", t = 1:10)[[2]]$est

cbind(true_model,applied,applied2,theoretical)

undebug(predict)
glm_fit$linear.predictors

df_collapse_all$haz_predict <- exp(predict(glm_fit))/df_collapse_all$atRisk2 # why does it work better with df_collapse_all$texpos_sum
df_collapse_all$log_haz_predict <- log(df_collapse_all$haz_predict)

df_collapse_all_St <-df_collapse_all%>% group_by(Treatment) %>% summarize(St = exp(-cumsum(haz_predict)))
df_collapse_all$St <-df_collapse_all_St$St

#https://m-clark.github.io/posts/2020-06-15-predict-with-offset/
ggplot(df_collapse_all, aes(x = log(timegroup), y = log(haz), color = Treatment))+
  geom_point()+
  geom_line(aes(x = log(timegroup), y = log_haz_predict, color = Treatment))
  

#install.packages("eha")
eha::phreg(formula = Surv( time, status) ~ as.factor(Treatment),
           data = TA269_df_all, dist = "weibull")


predict(glm_fit)

cbind(fit_flexsurv$res.t[,1], glm_fit$coefficients)

fit_flexsurv <- flexsurv::flexsurvreg(Surv(time,status)~as.factor(Treatment),
                                      data =TA269_df_all, dist = "weibullPH" )

dac_flg <- df_collapse_all$Treatment == "Dacarbazine"

plot(fit_flexsurv)
lines(df_collapse_all$timegroup[dac_flg], df_collapse_all$St[dac_flg], col = "blue" )
lines(df_collapse_all$timegroup[!dac_flg], df_collapse_all$St[!dac_flg], col = "purple" )
# exp(intercept) is equal to scale
# exp(Beta for log(t)) is approx equal to shape
# exp(beta for trt) is equal to HR


#would this work for a change-point problem? 
# possibly? the log offset would allow us to track time after change-point;
# while there would be no need to change the log(time) that could be as is.

#https://stats.stackexchange.com/questions/17073/equivalence-of-poisson-and-weibull-ph-regression-in-a-survival-setting

glm(status_sum ~ log(timegroup) + Treatment + offset(log(atRisk2)), family=poisson, data=df_collapse_all)


jags.piecewise_wei_chng_discrete <-"

model {

  #Constant for zerors trick
  C <- 10000
  c_small <- 0.00001
  #Prior for change-point locations - See Chapell
  cp[1] = 0  # mcp helper value. Should be zero
  cp[N_CP+2] = 9999  # mcp helper value. very large number

  for(k in 1:N_CP){
  #make sure the two changepoints are not at the same time
    unif[k] ~ dunif(t_int, time_distinct[length(time_distinct)-1]);
  }
  cp_x[2:(N_CP+1)] <- sort(unif)

  for(i in 2:(N_CP+1)){
  
   for(j in 1:(length(time_distinct)-1)){
    cp_ind[i,j] <- step(cp_x[i]-time_distinct[j])*step(time_distinct[j+1]-cp_x[i])*time_distinct[j]
   }
   
   cp_y[i] <- sum(cp_ind[i,]) #if none in the interval should be zero
   cp_t[i] <- cp_x[i]*equals(cp_fixed,0) + cp_fix[i]*equals(cp_fixed,1)
  }

  #for(i in 2:(N_CP+1)){
  #  diff[i-1] <- cp[i]-cp[i-1]
  #}

  #log_prior <- loggam(2*N_CP +2) + sum(log(diff)) - ((2*N_CP +1)*log(MAXX))
  #zero_prior ~ dpois(C - log_prior)

  #Prior for the model parameters

  for(i in 1:2){
    sd[i]  <- 5 # ~ dunif(0.2,5)
    prec[i] <- pow(sd[i], -2)
  }

  for(k in 1:(N_CP+1)){
    
    for(j in 1:n_covar){
      beta_cp_x[j,k] ~ dnorm(0,prec[1])
      beta_cp_temp[j,k] <- beta_cp_x[j,1]*equals(beta_ind[j,k],2) + beta_cp_x[j,k]*(1-equals(beta_ind[j,k],2))
    }
     
      #beta_cp_x[k] ~ dnorm(0,prec[1])
      #beta_cp_anc_x[k] ~ dnorm(0,prec[1])
      #beta_trt_x[k]~ dnorm(0,prec[1])
      #if 2 we have a common value of the covariate across the time-points;
      #otherwise we have different change-point models.
      #beta_cp[k] <- beta_cp_x[1]*equals(beta_1_ind[k],2) + beta_cp_x[k]*(1-equals(beta_1_ind[k],2))
      #beta_cp_anc[k] <- beta_cp_anc_x[1]*equals(beta_2_ind[k],2) + beta_cp_anc_x[k]*(1-equals(beta_2_ind[k],2))
      #beta_trt[k] <- beta_trt_x[1]*equals(beta_trt_ind[k],2) + beta_trt_x[k]*(1-equals(beta_trt_ind[k],2))
    
  }


  # Model and likelihood
  for (i in 1:N) {

    for(k in 1:(N_CP+1)){
      #variable which gives the difference between the two intervals if time[i]>cp[k+1]
      #(i.e. cp[k+1] -cp[k]) or time between time[i] and cp[k]
      #X[i,k] = max(min(time[i], cp_t[k+1]) - cp_t[k],0)

      #Indicator variable which highlights which interval time is in
      X_ind[i,k] = step(time[i]-cp_t[k])*step(cp_t[k+1]-time[i])

      for(j in 1:n_covar){
      beta_cp_ik[i,j,k]  <- beta_cp_temp[j,k]*X_ind[i,k] 
      }
    }
      for(j in 1:n_covar){
      beta_cp_i[i,j]  <- sum(beta_cp_ik[i,j,]) 
      y_vec[i,j] <- X_mat[i,j]*beta_cp_i[i,j]
    }
    y[i] <- sum(y_vec[i,])
    #y[i] <- beta_cp_i[i] + beta_cp_anc_i[i]*log(time[i]) + beta_trt_i[i] 
    lambda_offset[i] <- exp(y[i]+ log(atRisk[i]))
    n_events[i] ~ dpois(lambda_offset[i])
    lambda[i] <- exp(y[i])
  }
  
  
    for(k in 1:(N_CP+1)){
    
      beta_cp[1,k] <- beta_cp_temp[1,k] 
      beta_cp[2,k] <- beta_cp_temp[3,k]
      
      beta_cp_anc[1,k] <- beta_cp_temp[2,k] 
      beta_cp_anc[2,k] <- 0
    }
  


}

"




data_jags <- list()
data_jags$N <- nrow(df_collapse_all)
data_jags$time <- df_collapse_all$timegroup
data_jags$atRisk <- df_collapse_all$atRisk2
data_jags$n_events <- df_collapse_all$status_sum 
data_jags$X_mat <- cbind(1,log(data_jags$time),as.numeric(df_collapse_all$Treatment)-1)
data_jags$n_covar <- ncol(data_jags$X_mat)
data_jags$time_distinct <- unique(df_collapse_all$timegroup)
data_jags$t_int <- unique(diff(data_jags$time_distinct ))

data_jags$MAXX <- max(df_collapse_all$timegroup)
data_jags$N_CP <- 1
data_jags$cp_fix <- c(0, 1, 5)
data_jags$cp_fixed <- 0

data_jags$beta_ind <- rbind(rep(2,2),rep(2,2),rep(1,1))
                            

mod.cp <- runjags::run.jags(
  model = get("jags.piecewise_wei_chng_discrete"),
  data = data_jags,
  n.chains = 2,
  monitor = c("cp", "beta_cp", "lambda"),
  sample=n.samp,
  thin = n.thin,
  burnin = n.burnin,
  inits = inits,
  method ='rjparallel',
  summarise = FALSE)

summary_mod <- add.summary(mod.cp, c("beta","cp"))
summary_mod_percentiles <- summary_mod[["summary"]][[2]]


model_mat <- as.matrix(mod.cp$mcmc)
model_haz <- model_mat[,grep("lambda",colnames(model_mat))]
length(1:17)
length(18:34)

cum_haz_mat_comp <- apply(model_haz[,1:17],1,cumsum)
cum_haz_mat_trt <- apply(model_haz[,18:34],1,cumsum)
St_mat_comp <- exp(-cum_haz_mat_comp)
St_mat_trt <- exp(-cum_haz_mat_trt)
#rowMeans(St_mat_comp)
#rowMeans(St_mat_trt)

plot(fit_flexsurv)
#lines(df_collapse_all$timegroup[dac_flg], df_collapse_all$St[dac_flg], col = "blue" )
#lines(df_collapse_all$timegroup[!dac_flg], df_collapse_all$St[!dac_flg], col = "purple" )
#lines(seq_x, flexsurv::pweibullPH(seq_x,shape = shape_base, scale = scale_base, lower.tail = FALSE))
lines(x = 1:17, y =rowMeans(St_mat_comp), col= "blue" )
lines(x = 1:17, y =rowMeans(St_mat_trt), col= "blue" )

plot(density(model_mat[, "cp[2]"]))


haz_mat_comp <- apply(model_haz[,1:17],2,median)
haz_mat_trt <- apply(model_haz[,18:34],2,median)


plot(fit_flexsurv, type = "haz")
#lines(df_collapse_all$timegroup[dac_flg], df_collapse_all$St[dac_flg], col = "blue" )
#lines(df_collapse_all$timegroup[!dac_flg], df_collapse_all$St[!dac_flg], col = "purple" )
#lines(seq_x, flexsurv::pweibullPH(seq_x,shape = shape_base, scale = scale_base, lower.tail = FALSE))
lines(x = 1:17, y =haz_mat_comp, col= "blue" )
lines(x = 1:17, y =haz_mat_trt, col= "blue" )








jags.piecewise_wei_wane_discrete <-"

model {

  #Constant for zerors trick
  C <- 10000
  c_small <- 0.00001
  #Prior for change-point locations - See Chapell
  cp[1] = 0  # mcp helper value. Should be zero
  cp[N_CP+2] = 9999  # mcp helper value. very large number

  cp_y[1] = 0
  cp_y[N_CP+2] =999

  for(k in 1:N_CP){
  #make sure the two changepoints are not at the same time
    unif[k] ~ dunif(t_int, time_distinct[length(time_distinct)-1]);
  }
  cp_x[2:(N_CP+1)] <- sort(unif)

  for(i in 2:(N_CP+1)){
  
   for(j in 1:(length(time_distinct)-1)){
    cp_ind[i,j] <- step(cp_x[i]-time_distinct[j])*step(time_distinct[j+1]-cp_x[i])*time_distinct[j]
   }
   
   cp_y[i] <- sum(cp_ind[i,]) #if none in the interval should be zero
   cp_t[i] <- cp_x[i]*equals(cp_fixed,0) + cp_fix[i]*equals(cp_fixed,1)
  }

  #for(i in 2:(N_CP+1)){
  #  diff[i-1] <- cp[i]-cp[i-1]
  #}

  #log_prior <- loggam(2*N_CP +2) + sum(log(diff)) - ((2*N_CP +1)*log(MAXX))
  #zero_prior ~ dpois(C - log_prior)

  #Prior for the model parameters

  for(i in 1:2){
    sd[i]  <- 5 # ~ dunif(0.2,5)
    prec[i] <- pow(sd[i], -2)
  }

  for(k in 1:(N_CP+1)){
    
    for(j in 1:n_covar){
      beta_cp_x[j,k] ~ dnorm(0,prec[1])
      beta_cp_temp[j,k] <- beta_cp_x[j,1]*equals(beta_ind[j,k],2) + beta_cp_x[j,k]*(1-equals(beta_ind[j,k],2))
    }
   
  }

  ln_lambda_wane ~ dunif(-3,1.1)
  lambda_wane <- exp(ln_lambda_wane)

  initial_HR <-   exp(beta_cp_temp[trt_ind,N_CP])


  # Model and likelihood
  for (i in 1:N) {

    for(k in 1:(N_CP)){
    
      #Indicator variable which highlights which interval time is in
      X_ind[i,k] = step(time[i]-cp_t[k])*step(cp_t[k+1]-time[i])

      for(j in 1:n_covar){
      beta_cp_ik[i,j,k]  <- beta_cp_temp[j,k]*X_ind[i,k] 
      }
    }
    
    for(k in (N_CP+1):(N_CP+1)){
      #variable which gives the difference between the two intervals if time[i]>cp[k+1]
      #(i.e. cp[k+1] -cp[k]) or time between time[i] and cp[k]
      X[i,k] = max(min(time[i], cp_y[k+1]) - cp_y[k],0)#cp_y gives the full interval
      X_ind[i,k] = step(time[i]-cp_t[k])*step(cp_t[k+1]-time[i]) 
      HR_wane[i] <- 1-(1-initial_HR)*exp(-lambda_wane*X[i,k])

      for(j in 1:n_covar){
        beta_cp_ik[i,j,k]  <- (1-equals(j,trt_ind))*beta_cp_temp[j,k]*X_ind[i,k] +equals(j,trt_ind)*(log(HR_wane[i]))*X_ind[i,k]
      }
    }
    
      for(j in 1:n_covar){
      beta_cp_i[i,j]  <- sum(beta_cp_ik[i,j,]) 
      y_vec[i,j] <- X_mat[i,j]*beta_cp_i[i,j]
      }
    
    y[i] <- sum(y_vec[i,])
    #y[i] <- beta_cp_i[i] + beta_cp_anc_i[i]*log(time[i]) + beta_trt_i[i] 
    lambda_offset[i] <- exp(y[i]+ log(atRisk[i]))
    n_events[i] ~ dpois(lambda_offset[i])
    lambda[i] <- exp(y[i])
  }
  
  
    for(k in 1:(N_CP+1)){
    
      beta_cp[1,k] <- beta_cp_temp[1,k] 
      beta_cp[2,k] <- beta_cp_temp[3,k]
      
      beta_cp_anc[1,k] <- beta_cp_temp[2,k] 
      beta_cp_anc[2,k] <- 0
    }
  


}

"
mod.cp <- runjags::run.jags(
  model = get("jags.piecewise_wei_wane_discrete"),
  data = data_jags,
  n.chains = 2,
  monitor = c("cp", "beta_cp","beta_cp_anc", "lambda", "lambda_wane","HR_wane", "initial_HR"),
  sample=n.samp,
  thin = n.thin,
  burnin = n.burnin,
 # inits = inits,
  method ='rjparallel',
  summarise = FALSE)


#Try the e1690 data

pathway <- "~/Change-Point Simulation Studies/Simulation Study 2023/"

E1690.dat <- read.table(paste0(pathway,"e1690.missing.dat"),
                        header=TRUE)

# Ibhrahim data
#Drop PFS events with time equal zero
E1690.dat <- E1690.dat[-which(E1690.dat$FAILTIME ==0),]

#Convert to the correct notation for survival objects
E1690.dat[which(E1690.dat$FAILCENS == 1),"FAILCENS"] <-0
E1690.dat[which(E1690.dat$FAILCENS == 2),"FAILCENS"] <-1
E1690.dat[which(E1690.dat$SURVCENS == 1),"SURVCENS"] <-0
E1690.dat[which(E1690.dat$SURVCENS == 2),"SURVCENS"] <-1
E1690.dat$AGE <- as.numeric(E1690.dat$AGE)
E1690.dat$AGE[is.na(E1690.dat$AGE)] <- mean(E1690.dat$AGE, na.rm = T)
E1690.dat$AGE_scale <- as.numeric(scale(E1690.dat$AGE))
E1690.dat$AGE_scale_abs <- abs(E1690.dat$AGE_scale)
E1690.dat$TRT <- E1690.dat$TRT -1


E1690.dat <- E1690.dat %>% mutate(Treatment = ifelse(TRT == 1, "INF", "OBS"))
E1690.dat$Treatment <- as.factor(E1690.dat$Treatment)
E1690.dat$Treatment <- relevel(E1690.dat$Treatment, ref ="OBS")

E1690.dat_final <- E1690.dat[,c("SURVTIME","SURVCENS","TRT", "AGE_scale")]
colnames(E1690.dat_final) <- c("time", "status", "Treatment", "age_scale")


df <- E1690.dat_final
time_int <- 0.25
beta_ind <- cbind(c(1,1,1),c(1,1,1))

make_data_jags2 <- function(df,  beta_ind, time_int){

fit.km <- survfit(Surv(time, status)~Treatment,
                  data = df)
fit.km.event <- survfit(Surv(time, status)~Treatment,
                  data = df %>% filter(status == 1))
df_comb <- data.frame(time = fit.km.event$time, factor= rep(letters[1:length(fit.km.event$strata)], times = fit.km.event$strata))  
t_max <- df_comb  %>% group_by(factor) %>% summarize(max_val = floor(max(time))) %>% pull(max_val) %>% min()

df$time2 <- df$time
df <- cbind(tstart = 0,df) %>% mutate(
    time = ifelse(time2 > t_max, t_max,time2),
    status = ifelse(time2 > t_max , 0, status))

time_cuts <- seq(0,t_max-time_int, by = time_int)
time_cuts2 <- c(time_cuts[-1], max(time_cuts) +time_int)

sumdf <- summary(fit.km, t = time_cuts)
sumdf_2 <- summary(fit.km, t = time_cuts2)
df_collapse <- survival::survSplit(Surv(time, status) ~Treatment, df,
                                   cut=time_cuts[-1], episode ="timegroup") 
df_collapse_all <- df_collapse %>% mutate(texpos = time-tstart) %>%
    group_by(timegroup,tstart,Treatment) %>% 
  summarize(status_sum = sum(status),
            texpos_sum = sum(texpos)) %>% mutate(haz = status_sum/texpos_sum, tend = tstart + time_int) %>%
  ungroup() %>% group_by(Treatment) %>% arrange(Treatment)

df_collapse_all$atRisk <- (sumdf$n.risk+c(sumdf_2$n.risk))*time_int/2


data_jags <- list()
data_jags$N <- nrow(df_collapse_all)
data_jags$time <- df_collapse_all$tend
data_jags$atRisk <- df_collapse_all$atRisk2
data_jags$n_events <- df_collapse_all$status_sum 
data_jags$X_mat <- cbind(1,log(data_jags$time),as.numeric(df_collapse_all$Treatment))
data_jags$n_covar <- ncol(data_jags$X_mat)
data_jags$time_distinct <- unique(df_collapse_all$tend)
data_jags$t_int <- unique(diff(data_jags$time_distinct ))
data_jags$MAXX <- max(df_collapse_all$timegroup)
data_jags$N_CP <- 1
data_jags$cp_fix <- c(0, 1, 5)
data_jags$cp_fixed <- 0
data_jags$beta_ind <- beta_ind

data_jags

}

mod.cp <- runjags::run.jags(
  model = get("jags.piecewise_wei_wane_discrete"),
  data = data_jags,
  n.chains = 2,
  monitor =c("cp", "beta_cp", "lambda", "lambda_wane","HR_wane", "initial_HR"),
  sample=n.samp,
  thin = n.thin,
  burnin = n.burnin,
  inits = inits,
  method ='rjparallel',
  summarise = FALSE)


summary_mod <- add.summary(mod.cp, c("beta","cp","lambda_wane","HR_wane","initial_HR"))
summary_mod_percentiles <- summary_mod[["summary"]][[2]]


model_mat <- as.matrix(mod.cp$mcmc)
model_haz <- model_mat[,grep("lambda",colnames(model_mat))]


cum_haz_mat_comp <- apply(model_haz[,1:length(time_cuts2)]*time_int,1,cumsum)
cum_haz_mat_trt <- apply(model_haz[,(length(time_cuts2)+1):(2*length(time_cuts2))]*time_int,1,cumsum)
St_mat_comp <- exp(-cum_haz_mat_comp)
St_mat_trt <- exp(-cum_haz_mat_trt)
#rowMeans(St_mat_comp)
#rowMeans(St_mat_trt)

fit_flexsurv <- flexsurv::flexsurvreg(Surv(time,status)~as.factor(Treatment),
                                      data =E1690.dat_final, dist = "weibullPH" )


plot(fit_flexsurv)
#lines(df_collapse_all$timegroup[dac_flg], df_collapse_all$St[dac_flg], col = "blue" )
#lines(df_collapse_all$timegroup[!dac_flg], df_collapse_all$St[!dac_flg], col = "purple" )
#lines(seq_x, flexsurv::pweibullPH(seq_x,shape = shape_base, scale = scale_base, lower.tail = FALSE))
lines(x =time_cuts2, y =rowMeans(St_mat_comp), col= "blue" )
lines(x = time_cuts2, y =rowMeans(St_mat_trt), col= "blue" )

plot(density(model_mat[, "cp[2]"]))


haz_mat_comp <- apply(model_haz[,1:length(time_cuts2)],2,median)
haz_mat_trt <- apply(model_haz[,(length(time_cuts2)+1):(2*length(time_cuts2))],2,median)


plot(fit_flexsurv, type = "haz")
#lines(df_collapse_all$timegroup[dac_flg], df_collapse_all$St[dac_flg], col = "blue" )
#lines(df_collapse_all$timegroup[!dac_flg], df_collapse_all$St[!dac_flg], col = "purple" )
#lines(seq_x, flexsurv::pweibullPH(seq_x,shape = shape_base, scale = scale_base, lower.tail = FALSE))
lines(x =time_cuts2, y =haz_mat_comp, col= "blue" )
lines(x =time_cuts2, y =haz_mat_trt, col= "blue" )


plot(x =time_cuts2, y =haz_mat_comp, col= "blue" )
lines(x =time_cuts2, y =haz_mat_trt, col= "blue" )



